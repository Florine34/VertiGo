GitMerge-for-Unity
==================

A Unity plugin which allows you to merge scene and prefab files when using git.
More information: http://flashg.github.io/GitMerge-for-Unity/

### This tool does not work with Unity 5...

...and it will not do so until a small change in scene serialization will be reverted in Unity.
Please vote for this here: http://feedback.unity3d.com/suggestions/re-add-local-identifiers-in-scene-file-for-prefab-instances

## Current state of the project

You can merge both scenes and prefabs.
Working with the scene hierarchy is currently being improved.

There are still a few bugs to work on. If the tool messes up something, remember to git reset --hard :wink:
